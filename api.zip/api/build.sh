mvn package
java -jar /api-server/target/EmpManager.jar
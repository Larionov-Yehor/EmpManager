package employee.service;

import employee.model.Employee;

import java.util.List;

/**
 * Created by employee on 12/6/16.
 */
public interface EmployeeService {
    public List<Employee> getAll();
}
